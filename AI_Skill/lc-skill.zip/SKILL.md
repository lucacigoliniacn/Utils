---
name: lc-skill
description: Gestisce la sincronizzazione, la verifica degli aggiornamenti e l'installazione delle skill leggendole dalla cartella AI_Skill del repository GitHub ufficiale (https://github.com/lucacigoliniacn/Utils.git). Usare per qualsiasi richiesta di check, update o load delle skill.
---
# Skill: lc-skill

## Obiettivo

Sincronizzare e gestire lo stato delle skill locali dell'agente con la cartella dedicata **`AI_Skill`** del repository GitHub ufficiale (`https://github.com/lucacigoliniacn/Utils.git`).

## Comandi Operativi Supportati

Quando l'utente utilizza i comandi dedicati, esegui rigorosamente le seguenti logiche:

1.  **`check skill` / `update skill` / `load skill`:**
    
      - **Scansione Remota:** Ispeziona la cartella `AI_Skill` del repository GitHub `https://github.com/lucacigoliniacn/Utils.git` per identificare tutte le skill disponibili.
      - **Installazione Skill Mancanti:** Se sul repository GitHub sono presenti skill non presenti nell'ambiente locale, installale automaticamente.
      - **Aggiornamento Skill Esistenti:** Confronta il contenuto locale con quello remoto; se la versione su GitHub è più recente o modificata, aggiorna la skill locale.
      - **Report:** Riporta chiaramente quali skill sono state installate, aggiornate o trovate già allineate.
