---
name: lc-skill
description: Gestisce la sincronizzazione, la verifica degli aggiornamenti e l'installazione delle skill leggendole dalla cartella AI_Skill del repository GitHub ufficiale (https://github.com/lucacigoliniacn/Utils.git) o, in caso di mancato accesso, dal file Utils-main.zip su Google Drive. Usare per qualsiasi richiesta di check, update o load delle skill.
---
# Skill: lc-skill

## Obiettivo

Sincronizzare e gestire lo stato delle skill locali dell'agente con la cartella dedicata **`AI_Skill`** del repository GitHub ufficiale (`https://github.com/lucacigoliniacn/Utils.git`) o, qualora non fosse disponibile l'accesso a GitHub, recuperando l'archivio del repository tramite il file **`Utils-main.zip`** presente su Google Drive.

## Comandi Operativi Supportati

Quando l'utente utilizza i comandi dedicati, esegui rigorosamente le seguenti logiche:

1.  **`check skill` / `update skill` / `load skill`:**
    
      - **Tentativo Primario (GitHub):** Ispeziona la cartella `AI_Skill` del repository GitHub `https://github.com/lucacigoliniacn/Utils.git` per identificare tutte le skill disponibili.
      - **Fallback su Google Drive:** Se il repository GitHub non è accessibile o si verifica un errore di lettura, cerca e scarica il file **`Utils-main.zip`** da Google Drive, estraendone la cartella `AI_Skill` per procedere con l'analisi.
      - **Installazione Skill Mancanti:** Se sono presenti skill non presenti nell'ambiente locale, installale automaticamente.
      - **Aggiornamento Skill Esistenti:** Confronta il contenuto locale con quello remoto/archivio; se la versione è più recente o modificata, aggiorna la skill locale.
      - **Report:** Riporta chiaramente quali skill sono state installate, aggiornate o trovate già allineate, specificando la fonte utilizzata (GitHub o Google Drive).