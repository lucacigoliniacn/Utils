---
name: lc-skill
description: Gestisce la sincronizzazione, la verifica degli aggiornamenti e l'installazione delle skill leggendole dalla cartella AI_Skill del repository GitHub ufficiale (https://github.com/lucacigoliniwork/Cigo.git). Usare per qualsiasi richiesta di check, update, load o save delle skill.
---
# Skill: lc-skill

## Obiettivo
Sincronizzare e gestire lo stato delle skill locali dell'agente con la cartella dedicata **`AI_Skill`** del repository GitHub ufficiale (`https://github.com/lucacigoliniwork/Cigo.git`).

## Comandi Operativi Supportati

Quando l'utente utilizza i comandi dedicati, esegui rigorosamente le seguenti logiche:

1. **`check skill` / `update skill` / `load skill`:**
   - **Scansione Remota:** Ispeziona la cartella `AI_Skill` del repository GitHub per identificare tutte le skill disponibili.
   - **Installazione Skill Mancanti:** Se sul repository GitHub sono presenti skill non presenti nell'ambiente locale, installale automaticamente.
   - **Aggiornamento Skill Esistenti:** Confronta il contenuto locale con quello remoto; se la versione su GitHub è più recente o modificata, aggiorna la skill locale.
   - **Report:** Riporta chiaramente quali skill sono state installate, aggiornate o trovate già allineate.

2. **`save skill` (Push Inverso):**
   - Prende le skill attualmente presenti e aggiornate nell'ambiente locale e **aggiorna il codice su GitHub** (nella cartella `AI_Skill`) in base ad esse. Chiedi conferma prima di procedere con la scrittura/commit verso il repository remoto.
