---
name: lc-skill
description: Gestisce la sincronizzazione e l'aggiornamento delle skill leggendole da GitHub (https://github.com/lucacigoliniacn/Utils.git) o tramite l'archivio ZIP caricato dall'utente.
---
# Skill: lc-skill

## Obiettivo

Sincronizzare e gestire lo stato delle skill locali dell'agente con la cartella **`AI_Skill`** del repository GitHub ufficiale (`https://github.com/lucacigoliniacn/Utils.git`). 

## Comandi Operativi Supportati

Quando l'utente richiede un controllo, un aggiornamento o il caricamento delle skill (`check skill`, `update skill`, `load skill`), esegui rigorosamente le seguenti logiche:

1.  **Tentativo Primario (GitHub):**
    * Tenta di ispezionare la cartella `AI_Skill` del repository GitHub `https://github.com/lucacigoliniacn/Utils.git`.
2.  **Gestione del Fallback:**
    * Se il repository GitHub non è accessibile o non può essere letto direttamente, **mostra il link del repository** (`https://github.com/lucacigoliniacn/Utils.git`) all'utente, chiedendogli di scaricare l'archivio ZIP e di caricarlo direttamente in chat.
3.  **Elaborazione Archivio ZIP:**
    * Quando l'utente carica il file ZIP del repository, decomprimi e analizza l'archivio, individua la cartella `AI_Skill` ed esegui:
      - Installazione delle skill mancanti.
      - Aggiornamento delle skill esistenti se modificate.
      - Report finale dettagliato delle operazioni eseguite.
